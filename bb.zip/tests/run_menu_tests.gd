extends SceneTree
## Автопроверка потока «загрузка -> меню -> Играть -> карта».
## Запуск под Xvfb (нужно настоящее окно для GUI-ввода):
##   DISPLAY=:99 godot --path <проект> --script res://tests/run_menu_tests.gd

var _fails: int = 0
var _main: Node
var _loading: Control
var _menu: Control


func _initialize() -> void:
	print("=== Тесты загрузки и меню ===")
	_t()


func _t() -> void:
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(_main)
	current_scene = _main
	await _frames(5)

	_loading = _main.get_node("Loading")
	_menu = _main.get_node("Menu")

	await _test_initial_loading()
	await _test_menu_layout()
	await _test_tabs()
	await _test_play_flow()

	print("=== Результат: %s ===" % ("ВСЕ ТЕСТЫ ПРОЙДЕНЫ" if _fails == 0 else "%d ПРОВАЛОВ" % _fails))
	quit(0 if _fails == 0 else 1)


func _frames(n: int) -> void:
	for i in range(n):
		await physics_frame


func _wait_until(cond: Callable, max_frames: int = 600) -> bool:
	for i in range(max_frames):
		if cond.call():
			return true
		await physics_frame
	return cond.call()


func _check(ok: bool, label: String, details: String = "") -> void:
	if ok:
		print("  [OK]   %s" % label)
	else:
		_fails += 1
		print("  [FAIL] %s %s" % [label, details])


func _tap(pos: Vector2, index: int = 0) -> void:
	var d := InputEventScreenTouch.new()
	d.index = index
	d.position = pos
	d.pressed = true
	Input.parse_input_event(d)
	var r := InputEventScreenTouch.new()
	r.index = index
	r.position = pos
	r.pressed = false
	Input.parse_input_event(r)


func _center(n: Control) -> Vector2:
	return n.get_global_rect().get_center()


func _test_initial_loading() -> void:
	print("-- стартовая загрузка")
	_check(_loading.visible and not _menu.visible, "сначала виден экран загрузки, меню скрыто")
	var bar: ProgressBar = _loading.get_node("Bar")
	var v1: float = bar.value
	await _frames(15)
	var v2: float = bar.value
	_check(v2 > v1, "полоса загрузки анимируется (значение растёт)", "(%.1f -> %.1f)" % [v1, v2])
	_check(bar.value > 0.0 and bar.value <= 100.0, "значение в диапазоне 0–100", "(%s)" % bar.value)

	var pct1: String = (_loading.get_node("PctLabel") as Label).text
	var ok_done := await _wait_until(func(): return not _loading.visible and _menu.visible, 1200)
	_check(ok_done, "после 100%% загрузка гаснет и появляется меню")
	_check(bar.value >= 99.9, "полоса дошла до 100%", "(%s)" % bar.value)
	var pct2: String = (_loading.get_node("PctLabel") as Label).text
	_check(pct2 == "100%", "процент дописался до 100%", "(%s -> %s)" % [pct1, pct2])


func _test_menu_layout() -> void:
	print("-- раскладка меню")
	var left := _menu.get_node("LeftPanel") as Control
	_check(left.get_global_rect().size.y > 900.0 and left.get_global_rect().position.x < 5.0,
		"левая панель длинная и прижата к левому краю",
		"(rect=%s)" % left.get_global_rect())
	for name in ["TabPlay", "TabInventory", "TabSettings"]:
		_check(_menu.get_node_or_null("LeftPanel/Tabs/" + name) is Button, "иконка %s есть" % name)
	_check(_menu.get_node("LeftPanel/Tabs/TabPlay/Accent").visible, "вкладка Play активна при входе")
	_check(not _menu.get_node("LeftPanel/Tabs/TabSettings/Accent").visible, "Settings не активна")

	var avatar := _menu.get_node("RightBox/Profile/Avatar") as TextureRect
	var nick := _menu.get_node("RightBox/Profile/Nick") as Label
	_check(avatar.texture != null, "аватарка установлена")
	_check(nick.text.length() > 0, "никнейм есть", "(%s)" % nick.text)
	_check(nick.get_global_rect().position.x > avatar.get_global_rect().position.x,
		"никнейм правее аватарки")
	_check(_menu.get_node("RightBox/Stats/StatKD/VBox/Val").text == "1.37", "статистика K/D на месте")

	var btn := _menu.get_node("RightBox/PlayButton") as Button
	var r := btn.get_global_rect()
	_check(r.position.x > 1300.0 and r.position.y > 800.0, "кнопка «Играть» справа снизу", "(rect=%s)" % r)
	_check(btn.text == "Играть", "текст кнопки «Играть»")


func _test_tabs() -> void:
	print("-- переключение вкладок")
	_tap(_center(_menu.get_node("LeftPanel/Tabs/TabSettings")))
	var ok := await _wait_until(func(): return _menu.get_node("LeftPanel/Tabs/TabSettings/Accent").visible and not _menu.get_node("LeftPanel/Tabs/TabPlay/Accent").visible)
	_check(ok, "тап по Settings переносит активную вкладку")

	_tap(_center(_menu.get_node("LeftPanel/Tabs/TabInventory")))
	ok = await _wait_until(func(): return _menu.get_node("LeftPanel/Tabs/TabInventory/Accent").visible)
	_check(ok, "тап по Инвентарю переносит активную вкладку")

	_tap(_center(_menu.get_node("LeftPanel/Tabs/TabPlay")))
	ok = await _wait_until(func(): return _menu.get_node("LeftPanel/Tabs/TabPlay/Accent").visible)
	_check(ok, "тап по Play возвращает активную вкладку")


func _test_play_flow() -> void:
	print("-- кнопка «Играть» -> загрузка -> карта")
	_tap(_center(_menu.get_node("RightBox/PlayButton")))
	var ok := await _wait_until(func(): return _loading.visible and not _menu.visible)
	_check(ok, "после «Играть» меню скрылось и снова идёт загрузка")

	var to_game := await _wait_until(func(): return root.get_node_or_null("Game") != null, 1500)
	_check(to_game, "после загрузки произошла смена сцены на карту (Game)")
	await _frames(10)
	_check(root.get_node_or_null("Main") == null, "старая сцена меню выгружена")

	var game := root.get_node("Game")
	var player := game.get_node_or_null("Player") as CharacterBody3D
	_check(player is CharacterBody3D, "на карте есть игрок")
	var stick := game.get_node("HUD/Joystick") as Control
	player.transform.origin = Vector3(0, 0.05, 8)
	player.velocity = Vector3.ZERO
	await _frames(10)
	var c: Vector2 = stick.get_global_rect().get_center()
	var t := InputEventScreenTouch.new(); t.index = 0; t.position = c; t.pressed = true
	Input.parse_input_event(t)
	var d := InputEventScreenDrag.new(); d.index = 0; d.position = c + Vector2(0, -90); d.relative = Vector2(0, -90)
	Input.parse_input_event(d)
	var start: Vector3 = player.transform.origin
	var moved := await _wait_until(func(): return player.transform.origin.z < start.z - 1.0, 600)
	_check(moved, "после перехода джойстик работает и игрок идёт",
		"(Δz=%.2f)" % (player.transform.origin.z - start.z))
