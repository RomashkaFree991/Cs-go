extends SceneTree
## Автопроверка мобильного контроллера (тач-джойстик, поворот камеры, прыжок, физика).
## Запуск под виртуальным дисплеем, чтобы работал полноценный ввод:
##   Xvfb :99 -screen 0 1920x1080x24 &
##   DISPLAY=:99 godot --path <проект> --script res://tests/run_tests.gd

var _fails: int = 0
var _game: Node
var _player: CharacterBody3D
var _pitch: Node3D
var _stick: Control
var _look: Control
var _jump: Control


func _initialize() -> void:
	print("=== Тесты мобильного контроллера ===")
	_game = (load("res://scenes/game.tscn") as PackedScene).instantiate()
	root.add_child(_game)
	await _boot()

	_player = _game.get_node("Player")
	_pitch = _game.get_node("Player/CameraPivot")
	_stick = _game.get_node("HUD/Joystick")
	_look = _game.get_node("HUD/LookArea")
	_jump = _game.get_node("HUD/JumpButton")

	await _test_scene_structure()
	await _test_touch_joystick_drives_player()
	await _test_stick_release_stops_player()
	await _test_touch_look_rotates_camera()
	await _test_multitouch_walk_and_look()
	await _test_jump_button()
	await _test_gravity_and_floor()
	await _test_walls_block_player()
	await _test_keyboard_still_works()

	print("=== Результат: %s ===" % ("ВСЕ ТЕСТЫ ПРОЙДЕНЫ" if _fails == 0 else "%d ПРОВАЛОВ" % _fails))
	quit(0 if _fails == 0 else 1)


# ---------------------------------------------------------------- утилиты

func _boot() -> void:
	for i in range(5):
		await physics_frame


func _frames(n: int) -> void:
	for i in range(n):
		await physics_frame


## Ждёт до max_frames кадров, пока cond.call() не станет true.
## Нужно, потому что в X11 ввод доставляется на следующем кадре,
## а при программном рендере (llvmpipe) кадры длинные.
func _wait_until(cond: Callable, max_frames: int = 300) -> bool:
	for i in range(max_frames):
		if cond.call():
			return true
		await physics_frame
	return cond.call()


func _check(ok: bool, label: String, details: String = "") -> void:
	if ok:
		print("  [OK]   %s" % label)
	else:
		_fails += 1
		print("  [FAIL] %s %s" % [label, details])


func _touch_pressed(pos: Vector2, index: int = 0) -> void:
	var ev := InputEventScreenTouch.new()
	ev.index = index
	ev.position = pos
	ev.pressed = true
	Input.parse_input_event(ev)


func _touch_drag(pos: Vector2, index: int = 0, from: Vector2 = Vector2.ZERO) -> void:
	var ev := InputEventScreenDrag.new()
	ev.index = index
	ev.position = pos
	ev.relative = pos - from   # на реальном устройстве это делает сам Godot
	Input.parse_input_event(ev)


func _touch_released(pos: Vector2, index: int = 0) -> void:
	var ev := InputEventScreenTouch.new()
	ev.index = index
	ev.position = pos
	ev.pressed = false
	Input.parse_input_event(ev)


func _stick_center() -> Vector2:
	return _stick.get_global_rect().get_center()


func _release_all() -> void:
	_touch_released(_stick_center(), 0)
	_touch_released(Vector2(1500, 400), 1)
	_touch_released(_jump.get_global_rect().get_center(), 2)
	Input.action_release("move_forward")
	await _frames(2)


func _reset_player(at: Vector3) -> void:
	_player.transform.origin = at
	_player.velocity = Vector3.ZERO
	await _frames(2)


# ---------------------------------------------------------------- тесты

func _test_scene_structure() -> void:
	print("-- структура сцены")
	_check(_player != null, "Player (CharacterBody3D) найден")
	_check(_stick != null and _stick.has_signal("vector_changed"), "HUD/Joystick с сигналом vector_changed")
	_check(_look != null and _look.has_signal("look_delta"), "HUD/LookArea с сигналом look_delta")
	_check(_jump != null and _jump.has_signal("pressed"), "HUD/JumpButton с сигналом pressed")
	_check(_game.get_node_or_null("Player/CameraPivot/Camera3D") is Camera3D, "Camera3D на высоте глаз")
	var cam_y: float = _pitch.transform.origin.y
	_check(is_equal_approx(cam_y, 1.7), "камера на y=1.7", "(y=%s)" % cam_y)
	# CSG-боксы сами по себе коллизию НЕ создают — нужен CSGCombiner3D с use_collision.
	var platforms := _game.get_node("Platforms") as Node3D
	var space: PhysicsDirectSpaceState3D = platforms.get_world_3d().direct_space_state
	var q := PhysicsShapeQueryParameters3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(4, 4, 4)
	q.shape = box
	q.transform = Transform3D(Basis.IDENTITY, Vector3(0, 0.5, 0))
	_check(space.intersect_shape(q, 8).size() > 0, "у площадки есть физическая коллизия")


func _test_touch_joystick_drives_player() -> void:
	print("-- тач по джойстику -> игрок идёт")
	_pitch.rotation = Vector3.ZERO
	await _reset_player(Vector3(0, 0.05, 8))

	var center := _stick_center()
	_touch_pressed(center)
	_touch_drag(center + Vector2(0, -90))            # палец вверх = вперёд
	var got := await _wait_until(func(): return _stick.vector.y < -0.6)
	_check(got, "джойстик вернул вектор вперёд", "(vector=%s)" % _stick.vector)
	_check(_stick.get_node("Base").visible, "база джойстика показалась под пальцем")
	var knob := _stick.get_node("Base/Knob") as TextureRect
	var base := _stick.get_node("Base") as TextureRect
	var knob_off: Vector2 = knob.position - (base.size - knob.size) * 0.5
	_check(knob_off.y < -50.0, "ручка джойстика сместилась вверх", "(offset=%s)" % knob_off)

	var start := _player.transform.origin
	var moved_far := await _wait_until(func(): return _player.transform.origin.z < start.z - 1.0)
	var moved := _player.transform.origin - start
	_check(moved_far, "игрок сдвинулся вперёд (−Z)", "(Δz=%.3f)" % moved.z)
	_check(absf(moved.x) < 0.05, "вбок не уводит", "(Δx=%.3f)" % moved.x)

	_touch_released(center)
	var zeroed := await _wait_until(func(): return _stick.vector.length() < 0.001)
	_check(zeroed, "после отпускания вектор = 0", "(vector=%s)" % _stick.vector)
	_check(not base.visible, "после отпускания база джойстика скрылась")


func _test_stick_release_stops_player() -> void:
	print("-- отпустили джойстик -> игрок останавливается")
	await _reset_player(Vector3(0, 0.05, 8))
	await _frames(20)
	var before := _player.transform.origin
	await _frames(30)
	var drift: float = (_player.transform.origin - before).length()
	_check(drift < 0.05, "игрок стоит на месте", "(сдвиг=%.4f)" % drift)


func _test_touch_look_rotates_camera() -> void:
	print("-- свайп справа -> поворот камеры")
	_pitch.rotation = Vector3.ZERO
	var pos := Vector2(1500, 400)
	_touch_pressed(pos, 1)
	_touch_drag(pos + Vector2(-100, -50), 1, pos)
	var turned := await _wait_until(func():
		return rad_to_deg(_pitch.rotation.y) > 5.0 and rad_to_deg(_pitch.rotation.x) > 2.0)
	_touch_released(pos + Vector2(-100, -50), 1)
	await _frames(2)
	var yaw_deg := rad_to_deg(_pitch.rotation.y)
	var pitch_deg := rad_to_deg(_pitch.rotation.x)
	_check(yaw_deg > 5.0, "свайп влево повернул камеру влево", "(yaw=%.2f°)" % yaw_deg)
	_check(pitch_deg > 2.0, "свайп вверх поднял камеру", "(pitch=%.2f°)" % pitch_deg)
	_check(turned, "камера отреагировала на свайп")

	# Двойной свайп должен повернуть примерно вдвое сильнее.
	_pitch.rotation = Vector3.ZERO
	_touch_pressed(pos, 1)
	_touch_drag(pos + Vector2(-200, 0), 1, pos)
	await _wait_until(func(): return absf(rad_to_deg(_pitch.rotation.y)) > 1.0)
	_touch_released(pos + Vector2(-200, 0), 1)
	await _frames(2)
	var yaw2 := absf(rad_to_deg(_pitch.rotation.y))
	_check(yaw2 > yaw_deg * 1.5, "чем длиннее свайп — тем сильнее поворот",
		"(100px -> %.2f°, 200px -> %.2f°)" % [yaw_deg, yaw2])

	# Ограничение наклона: нельзя «перевернуться» через голову.
	for i in range(80):
		_touch_pressed(Vector2(1500, 900), 1)
		_touch_drag(Vector2(1500, 0), 1, Vector2(1500, 900))
		_touch_released(Vector2(1500, 0), 1)
	await _wait_until(func(): return rad_to_deg(_pitch.rotation.x) > 80.0, 120)
	var clamped := rad_to_deg(_pitch.rotation.x)
	_check(clamped <= 85.001 and clamped > 40.0, "наклон камеры ограничен 85°", "(pitch=%.2f°)" % clamped)
	_pitch.rotation = Vector3.ZERO


func _test_multitouch_walk_and_look() -> void:
	print("-- мультитач: одновременно идём и смотрим")
	_pitch.rotation = Vector3.ZERO
	await _reset_player(Vector3(0, 0.05, 8))

	var center := _stick_center()
	_touch_pressed(center, 0)
	_touch_drag(center + Vector2(90, 0), 0)          # палец 0 — вправо
	_touch_pressed(Vector2(1500, 400), 1)
	_touch_drag(Vector2(1400, 400), 1, Vector2(1500, 400))               # палец 1 — свайп влево

	var ok := await _wait_until(func():
		return _player.transform.origin.x > 0.5 and rad_to_deg(_pitch.rotation.y) > 2.0)
	_check(ok, "ходьба и поворот работают одновременно",
		"(x=%.2f, yaw=%.2f°)" % [_player.transform.origin.x, rad_to_deg(_pitch.rotation.y)])
	await _release_all()


func _test_jump_button() -> void:
	print("-- кнопка прыжка")
	await _reset_player(Vector3(0, 0.05, 8))
	var grounded := await _wait_until(func(): return _player.is_on_floor())
	_check(grounded, "игрок стоит на полу перед прыжком")

	var y0 := _player.transform.origin.y
	var btn := _jump.get_global_rect().get_center()
	_touch_pressed(btn, 2)
	var jumped := await _wait_until(func(): return _player.velocity.y > 0.0)
	_touch_released(btn, 2)
	_check(jumped, "после нажатия появилась скорость вверх", "(vy=%.2f)" % _player.velocity.y)
	_check(_jump.get_node("Texture").modulate.a > 0.5, "кнопка подсветилась при нажатии",
		"(alpha=%.2f)" % _jump.get_node("Texture").modulate.a)

	var peak := await _wait_until(func(): return _player.transform.origin.y > y0 + 0.5)
	_check(peak, "игрок подпрыгнул", "(y0=%.2f -> y=%.2f)" % [y0, _player.transform.origin.y])
	var landed := await _wait_until(func(): return _player.is_on_floor(), 600)
	_check(landed, "игрок приземлился", "(y=%.2f)" % _player.transform.origin.y)
	await _frames(10)
	_check(_jump.get_node("Texture").modulate.a < 0.5, "кнопка погасла после отпускания")


func _test_gravity_and_floor() -> void:
	print("-- гравитация и пол")
	await _reset_player(Vector3(0, 4.0, 8))
	var falling := await _wait_until(func(): return _player.velocity.y < -5.0)
	_check(falling, "в воздухе включается гравитация", "(vy=%.2f)" % _player.velocity.y)
	var landed := await _wait_until(func(): return _player.is_on_floor(), 900)
	_check(landed, "упал на пол и остановился")
	_check(absf(_player.transform.origin.y) < 0.02, "не провалился сквозь пол",
		"(y=%.3f)" % _player.transform.origin.y)


func _test_walls_block_player() -> void:
	print("-- стены не пускают за площадку")
	_pitch.rotation = Vector3(0, PI, 0)              # развернуться к южной стене
	await _reset_player(Vector3(0, 0.05, 8))

	var center := _stick_center()
	_touch_pressed(center)
	_touch_drag(center + Vector2(0, -100))
	var hit_wall := await _wait_until(func():
		return _player.transform.origin.z > 11.0 or _player.get_slide_collision_count() > 0, 900)
	await _frames(30)
	_touch_released(center)
	await _frames(5)
	var z: float = _player.transform.origin.z
	_check(z < 11.9, "игрок не прошёл сквозь стену", "(z=%.2f)" % z)
	_check(hit_wall, "игрок упёрся в стену / дошёл до края")
	_check(_player.transform.origin.y < 2.5, "игрок не вылетел с площадки",
		"(y=%.2f)" % _player.transform.origin.y)
	_pitch.rotation = Vector3.ZERO


func _test_keyboard_still_works() -> void:
	print("-- клавиатура (тест на ПК) тоже работает")
	await _reset_player(Vector3(0, 0.05, 0))
	Input.action_press("move_forward")
	var start := _player.transform.origin
	var moved := await _wait_until(func(): return _player.transform.origin.z < start.z - 0.5)
	Input.action_release("move_forward")
	_check(moved, "клавиша W двигает игрока вперёд",
		"(Δz=%.3f)" % (_player.transform.origin.z - start.z))
	await _frames(30)
