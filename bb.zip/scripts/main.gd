extends Node
## Оркестратор потока: загрузка -> меню -> (Играть) -> загрузка -> карта.

@onready var _loading: Control = $Loading
@onready var _menu: Control = $Menu

var _pending_game: bool = false


func _ready() -> void:
	_loading.finished.connect(_on_loading_done)
	_menu.play_pressed.connect(_on_play)
	_menu.visible = false
	_loading.start(2.0)


func _on_play() -> void:
	_menu.visible = false
	_pending_game = true
	_loading.start(1.0)


func _on_loading_done() -> void:
	if _pending_game:
		get_tree().change_scene_to_file("res://scenes/game.tscn")
	else:
		_menu.visible = true
