extends CharacterBody3D
## Игрок от первого лица: ходьба + прыжок.
## Вход идёт из двух источников: клавиатура/геймпад (для теста на ПК)
## и экранные контролы HUD (джойстик + зона поворота камеры + кнопка прыжка).

@export var gravity: float = 20.0
@export var speed: float = 5.5
@export var sprint_multiplier: float = 1.6
@export var jump_velocity: float = 8.0
@export var accel: float = 12.0
@export var decel: float = 14.0
## Чувствительность поворота камеры пальцем (градусы на пиксель свайпа).
@export var look_sensitivity: float = 0.12
## Максимальный наклон камеры вверх/вниз (градусы).
@export var pitch_limit_deg: float = 85.0

@onready var _pitch: Node3D = $CameraPivot
@onready var _cam: Camera3D = $CameraPivot/Camera3D

var _input_move := Vector2.ZERO   # клавиатура / геймпад
var _stick_move := Vector2.ZERO   # экранный джойстик
var _jump_queued := false


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var hud := _find_hud()
	if hud:
		var stick: Node = hud.get_node_or_null("Joystick")
		if stick and stick.has_signal("vector_changed"):
			stick.vector_changed.connect(_on_stick_vector)
		var look: Node = hud.get_node_or_null("LookArea")
		if look and look.has_signal("look_delta"):
			look.look_delta.connect(_on_look_delta)
		var btn: Node = hud.get_node_or_null("JumpButton")
		if btn and btn.has_signal("pressed"):
			btn.pressed.connect(_on_jump_pressed)


func _find_hud() -> Node:
	var root: Node = get_tree().current_scene if get_tree() else null
	if root:
		var hud: Node = root.get_node_or_null("HUD")
		if hud:
			return hud
	return get_node_or_null("../HUD")


func _unhandled_input(event: InputEvent) -> void:
	# Мышь на ПК: движение камеры, если курсор захвачен.
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		apply_look(Vector2(event.relative.x, event.relative.y))


func _physics_process(delta: float) -> void:
	# Клавиатура/геймпад опрашиваются напрямую — чтобы управление можно было
	# проверить на ПК и чтобы работало с Input.action_press() в автотестах.
	_input_move = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if Input.is_action_just_pressed("jump"):
		_jump_queued = true

	var input_dir: Vector2 = _input_move
	if input_dir.length() < 0.01:
		input_dir = _stick_move
	input_dir = input_dir.limit_length(1.0)

	if not is_on_floor():
		velocity.y -= gravity * delta

	var sprinting := Input.is_action_pressed("sprint")
	var target_speed: float = speed * (sprint_multiplier if sprinting else 1.0)

	var yaw: float = _pitch.rotation.y
	var dir3 := Vector3.ZERO
	if input_dir.length_squared() > 0.0001:
		var flat := Vector3(input_dir.x, 0.0, input_dir.y).rotated(Vector3.UP, yaw)
		dir3 = flat.normalized()

	var target := dir3 * target_speed
	var factor: float = accel if dir3.length_squared() > 0.0001 else decel
	velocity.x = move_toward(velocity.x, target.x, factor * delta)
	velocity.z = move_toward(velocity.z, target.z, factor * delta)

	if _jump_queued and is_on_floor():
		velocity.y = jump_velocity
	_jump_queued = false

	move_and_slide()


## Поворот камеры. delta — в пикселях (мышь или палец).
func apply_look(delta_px: Vector2) -> void:
	_pitch.rotate_y(deg_to_rad(-delta_px.x * look_sensitivity))
	var pitch_deg: float = rad_to_deg(_pitch.rotation.x) - delta_px.y * look_sensitivity
	_pitch.rotation.x = deg_to_rad(clampf(pitch_deg, -pitch_limit_deg, pitch_limit_deg))


func _on_stick_vector(v: Vector2) -> void:
	_stick_move = v


func _on_look_delta(d: Vector2) -> void:
	apply_look(d)


func _on_jump_pressed() -> void:
	_jump_queued = true
