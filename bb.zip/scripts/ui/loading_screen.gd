extends Control
## Экран загрузки: длинная полоса 0–100% с плавной анимацией заполнения,
## процентом и крутящейся шестерёнкой. Когда дошло до 100 — плавно гаснет
## и шлёт сигнал finished.

signal finished

@onready var _bar: ProgressBar = $Bar
@onready var _pct: Label = $PctLabel
@onready var _spinner: TextureRect = $Spinner

var target: float = 0.0     # куда «доехала» симуляция загрузки
var shown: float = 0.0      # то, что видно на полосе (плавно догоняет target)
var _active: bool = false
var _finishing: bool = false


func start(duration: float = 2.0) -> void:
	visible = true
	modulate.a = 1.0
	_active = true
	_finishing = false
	target = 0.0
	shown = 0.0
	_bar.value = 0.0
	_pct.text = "0%"
	_simulate(duration)


## Симуляция загрузки: цель ползёт к 100 случайными шагами,
## суммарно примерно за duration секунд.
func _simulate(duration: float) -> void:
	var step: float = 100.0 * 0.085 / maxf(0.3, duration)
	while _active and target < 100.0:
		await get_tree().create_timer(randf_range(0.05, 0.12)).timeout
		if not _active:
			return
		target = minf(100.0, target + randf_range(0.6, 1.4) * step)
	target = 100.0


func _process(delta: float) -> void:
	if not visible:
		return
	_spinner.rotation += delta * 5.0
	if not _active:
		return
	shown = move_toward(shown, target, delta * 80.0)
	_bar.value = shown
	_pct.text = "%d%%" % roundi(shown)
	if shown >= 100.0 and not _finishing:
		_finishing = true
		_active = false
		var tw := create_tween()
		tw.tween_interval(0.25)
		tw.tween_property(self, "modulate:a", 0.0, 0.35)
		tw.tween_callback(_done)


func _done() -> void:
	visible = false
	finished.emit()
