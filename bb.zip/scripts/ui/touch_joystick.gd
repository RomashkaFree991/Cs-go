class_name TouchJoystick
extends Control
## Экранный джойстик. Работает на touch и на мышке (для проверки на ПК).
## Палец можно ставить в любом месте экрана — база «прилипает» к точке касания.

signal vector_changed(v: Vector2)

@export var stick_radius: float = 110.0
@export var deadzone: float = 10.0
## Лимит выходного вектора: 1.0 = нельзя «передать» больше максимума.
@export var clamp_output: bool = true

@onready var _base: TextureRect = $Base
@onready var _knob: TextureRect = $Base/Knob

var _touch_index: int = -1
var _center := Vector2.ZERO
var vector := Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	_base.size = Vector2(stick_radius * 2.0, stick_radius * 2.0)
	_base.pivot_offset = _base.size * 0.5
	_base.position = -_base.size * 0.5
	_knob.pivot_offset = _knob.size * 0.5
	_reset()


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if _touch_index == -1:
				_touch_index = event.index
				_center = event.position
				_base.visible = true
				_base.position = _center - _base.size * 0.5
				_update(Vector2.ZERO)
		elif event.index == _touch_index:
			_release()
	elif event is InputEventScreenDrag:
		if event.index == _touch_index:
			_update(event.position - _center)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and _touch_index == -1:
			_touch_index = -2
			_center = event.position
			_base.visible = true
			_base.position = _center - _base.size * 0.5
			_update(Vector2.ZERO)
		elif not event.pressed and _touch_index == -2:
			_release()
	elif event is InputEventMouseMotion and _touch_index == -2:
		_update(event.position - _center)


func _update(offset: Vector2) -> void:
	var v := offset / stick_radius
	if offset.length() < deadzone:
		v = Vector2.ZERO
	if clamp_output:
		v = v.limit_length(1.0)
	vector = v
	_knob.position = (_base.size - _knob.size) * 0.5 + offset.limit_length(stick_radius)
	vector_changed.emit(vector)


func _release() -> void:
	_touch_index = -1
	_reset()


func _reset() -> void:
	vector = Vector2.ZERO
	_base.visible = false
	_knob.position = (_base.size - _knob.size) * 0.5
	vector_changed.emit(vector)
