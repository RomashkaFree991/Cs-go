extends Control
## Главное меню: слева панель иконок (Play — активная вкладка),
## справа профиль (аватарка, ник, статистика K/D) и зелёная кнопка «Играть».
## Пока всё визуальное — контент вкладок появится позже.

signal play_pressed
signal tab_changed(id: String)

@onready var _tabs: Dictionary = {
	"play": $LeftPanel/Tabs/TabPlay,
	"inventory": $LeftPanel/Tabs/TabInventory,
	"settings": $LeftPanel/Tabs/TabSettings,
}


func _ready() -> void:
	for id: String in _tabs:
		var btn: Button = _tabs[id]
		btn.pressed.connect(_on_tab.bind(id))
	$RightBox/PlayButton.pressed.connect(func(): play_pressed.emit())
	set_active_tab("play")


func set_active_tab(id: String) -> void:
	for key: String in _tabs:
		var btn: Button = _tabs[key]
		btn.get_node("Accent").visible = (key == id)
		btn.modulate = Color.WHITE if key == id else Color(0.55, 0.58, 0.62, 1.0)


func _on_tab(id: String) -> void:
	set_active_tab(id)
	tab_changed.emit(id)
