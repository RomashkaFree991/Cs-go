class_name TouchButton
extends Control
## Кнопка под палец (прыжок). Срабатывает на нажатие, а не на отпускание.

signal pressed

@export var allow_repeat: bool = false

@onready var _tex: TextureRect = $Texture
@onready var _label: Label = $Texture/Label

var _touch_index: int = -1
var _normal_color := Color(1, 1, 1, 0.30)
var _pressed_color := Color(1, 1, 1, 0.60)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	_tex.modulate = _normal_color


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if _touch_index == -1:
				_touch_index = event.index
				_set_pressed(true)
				pressed.emit()
		elif event.index == _touch_index:
			_release()
	elif event is InputEventScreenDrag:
		if event.index == _touch_index and allow_repeat:
			pressed.emit()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_touch_index = -2
			_set_pressed(true)
			pressed.emit()
		elif _touch_index == -2:
			_release()


func _set_pressed(state: bool) -> void:
	_tex.modulate = _pressed_color if state else _normal_color


func _release() -> void:
	_touch_index = -1
	_set_pressed(false)
