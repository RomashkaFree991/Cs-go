class_name TouchLookArea
extends Control
## Прозрачная зона справа: свайп пальцем поворачивает камеру.
## Отдаёт накопленное смещение в пикселях сигналом look_delta.

signal look_delta(delta: Vector2)

@export var invert_y: bool = false

var _touch_index: int = -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if _touch_index == -1:
				_touch_index = event.index
		elif event.index == _touch_index:
			_touch_index = -1
	elif event is InputEventScreenDrag:
		if event.index == _touch_index:
			_emit(Vector2(event.relative.x, -event.relative.y if invert_y else event.relative.y))
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_touch_index = -2 if event.pressed else -1
	elif event is InputEventMouseMotion and _touch_index == -2:
		_emit(event.relative)


func _emit(d: Vector2) -> void:
	if d.length_squared() > 0.0:
		look_delta.emit(d)
