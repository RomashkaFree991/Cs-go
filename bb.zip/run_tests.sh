#!/usr/bin/env bash
# Автотесты: геймплей + поток «загрузка/меню/Играть».
# Использование: GODOT_BIN=/путь/к/godot ./run_tests.sh
set -e
cd "$(dirname "$0")"
GODOT_BIN="${GODOT_BIN:-godot}"

run() {
  if command -v xvfb-run >/dev/null 2>&1; then
    xvfb-run -a -s "-screen 0 1920x1080x24" "$GODOT_BIN" --path . --script "$1"
  else
    echo "xvfb-run не найден: запускаю headless (GUI-тесты тача в headless не доставляются до Control)."
    "$GODOT_BIN" --headless --path . --script "$1"
  fi
}

run res://tests/run_tests.gd
run res://tests/run_menu_tests.gd
